import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'

class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { error: null } }
  static getDerivedStateFromError(e) { return { error: e } }
  render() {
    if (this.state.error) {
      return (
        <div style={{padding:40,fontFamily:'monospace',background:'#fff',color:'#1B3A6B',minHeight:'100vh'}}>
          <div style={{fontSize:24,fontWeight:700,marginBottom:16}}>S&H Deck Planner — Startup Error</div>
          <pre style={{background:'#f4f6fa',padding:16,borderRadius:8,fontSize:12,overflow:'auto',border:'1px solid #D1D9E8'}}>
            {this.state.error.toString()}{'\n'}{this.state.error.stack}
          </pre>
          <button onClick={()=>window.location.reload()} style={{marginTop:16,padding:'10px 24px',background:'#1B3A6B',color:'#fff',border:'none',borderRadius:8,cursor:'pointer',fontSize:14,fontWeight:700}}>
            Reload
          </button>
        </div>
      )
    }
    return this.props.children
  }
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
)
